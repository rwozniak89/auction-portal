import { FilterAuctionsPipe } from './filter-auctions.pipe';

describe('FilterAuctionsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterAuctionsPipe();
    expect(pipe).toBeTruthy();
  });
});
