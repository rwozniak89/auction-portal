export interface AuctionItem {
    id: number;
    title: string;
    imgUrl: string;
    description: string;
    price: number;
}
