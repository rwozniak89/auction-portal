export interface MenuItem {
    href: string;
    title: string;
}
