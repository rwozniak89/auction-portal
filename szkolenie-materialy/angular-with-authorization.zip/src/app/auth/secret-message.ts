export interface SecretMessage {
  name: string;
  role: string;
}
