import {Car} from './Car'

const carInstance = new Car();

carInstance.shoutMyName();
