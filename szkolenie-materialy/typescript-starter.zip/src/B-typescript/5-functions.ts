
let calculateTax: (amount: number, tax: number) => number;

calculateTax = function (value, tax) {
    return value + tax;
};

console.log(calculateTax(10, 3));


// #1 Pokaż zastosowanie w środku definicji przykładowego obiektu
