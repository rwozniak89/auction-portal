const hello2: string = 'Hello Typescript';

console.log(hello2);
