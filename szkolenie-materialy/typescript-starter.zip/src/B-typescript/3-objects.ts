

let tax: {name: string, amount: number, reason: string};

tax = {
  amount: 100,
  name: 'VAT',
  reason: 'za towar'
};

console.log(tax);

// #1 Utwórz nowy typ TaxAmount


// #2 co jeśli zmienimy let na const?


// #3 dodaj dodatkowe - opcjonalne pola dla typu

