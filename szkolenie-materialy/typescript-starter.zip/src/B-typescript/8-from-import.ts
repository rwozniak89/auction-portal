
const worker: {name: string, lastName: string} = {lastName: 'Smith', name: 'John'};

console.log(worker);

// #1 Utwórz interface Person

// #2 Zrób z interface oddzielny moduł, zaimportuj i użyj

