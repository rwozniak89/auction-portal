export default function greetings(name: string): string {
   return `Hello ${name}, my friend!`
}
