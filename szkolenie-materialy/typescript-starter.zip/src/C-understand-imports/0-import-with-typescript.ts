import greetings from './modules/greetings';

console.log(greetings('Michał'))

// Żeby Quokka zadziałała musimy zrobić:
// npm i -D ts-node tsconfig-paths

// doinstaluje to 2 zależności do dev:
// ts-node
// tsconfig-paths
