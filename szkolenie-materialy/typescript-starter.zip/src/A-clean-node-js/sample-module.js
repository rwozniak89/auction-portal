const sampleLogic = require('./sample-logic');

console.log(
	sampleLogic.myNumber,
	sampleLogic.myString,
	sampleLogic.myDecision
)
