const myString = 'Hello';
const myNumber = 2344;
const myObject = {name: 'Movie'}

module.exports = {
	myNumber: myNumber,
	myDecision: myObject,
	myString: myString
}

